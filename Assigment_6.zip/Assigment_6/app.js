const express = require('express');
const app = express();
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcrypt');

// Set the view engine to Pug
app.set('view engine', 'pug');
app.set('views', path.join(__dirname, 'views'));

// Middleware for parsing POST request bodies (for form data)
app.use(express.urlencoded({ extended: true }));

// Serve static files (CSS, JS, Images)
app.use(express.static(path.join(__dirname, 'public')));

// Path to the JSON file where user data is stored in the data folder
const usersFile = path.join(__dirname, 'data', 'users.json');

// Function to read users from JSON file
function readUsers() {
  try {
    const data = fs.readFileSync(usersFile, 'utf8');
    return JSON.parse(data);
  } catch (err) {
    return [];
  }
}

// Function to write users to JSON file
function writeUsers(users) {
  fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
}

// Routes
app.get('/', (req, res) => {
  res.render('home', { title: 'Home' });
});

app.get('/login', (req, res) => {
  res.render('login', { title: 'Login' });
});
app.get('/about', (req, res) => {
  res.render('about', { title: 'About' });
});

app.get('/register', (req, res) => {
  res.render('register', { title: 'Register' });
});

app.get('/dashboard', (req, res) => {
    res.render('dashboard');
  });
  
app.post('/register', async (req, res) => {
  const { username, email, password, firstName, lastName } = req.body;
  const users = readUsers();

  // Check if user already exists
  const existingUser = users.find(user => user.username === username);
  if (existingUser) {
    return res.render('register', { title: 'Register', error: 'Username already exists' });
  }

  // Store the password as plain text (NOT recommended)
  users.push({
    username,
    email,
    password, // storing plain-text password
    firstName,
    lastName,
  });

  // Save updated users to the JSON file
  writeUsers(users);

  // Redirect to success page
  res.redirect('/success');
});


app.get('/success', (req, res) => {
  res.render('success', { title: 'Registration Successful' });
});

// Start the server
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});