
document.getElementById('profileForm').addEventListener('submit', function(event) {
    event.preventDefault();
    // Implement profile update logic here (e.g., send data to server via AJAX)
    alert('Profile updated successfully!');
});

// Logic to change profile picture preview
document.getElementById('profilePhoto').addEventListener('change', function() {
    const file = this.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('profilePic').src = e.target.result;
        }
        reader.readAsDataURL(file);
    }
});
