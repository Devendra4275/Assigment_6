const express = require('express');
const multer = require('multer');
const path = require('path');
const app = express();

// Set up middleware for file upload (e.g., profile photos)
const storage = multer.diskStorage({
  destination: './uploads/',
  filename: function(req, file, cb) {
    cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ storage: storage });

app.set('view engine', 'pug');

// Dummy user data (in real projects, use database)
const user = { name: 'Anuhya', email: 'anuhya@example.com' };

app.get('/profile', (req, res) => {
  res.render('profile', { user });
});

app.post('/profile', upload.single('profilePhoto'), (req, res) => {
  // Handle profile update logic (e.g., save file, update user details)
  user.name = req.body.name;
  user.email = req.body.email;
  if (req.file) {
    user.profilePic = /uploads/;{req.file.filename};
  }
  res.redirect('/profile');
});

app.listen(3000, () => {
  console.log('Server started on port 3000');
});